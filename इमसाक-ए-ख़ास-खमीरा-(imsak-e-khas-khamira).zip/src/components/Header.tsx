import React from 'react';
import { Phone, ShieldCheck, Sparkles, ShoppingBag } from 'lucide-react';
import { PRODUCT_INFO } from '../data/productData';

interface HeaderProps {
  onOrderClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOrderClick }) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-amber-100 shadow-xs">
      {/* Announcement Bar */}
      <div className="bg-gradient-to-r from-amber-900 via-amber-800 to-amber-900 text-amber-50 py-2 px-3 text-xs md:text-sm text-center font-medium">
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 flex-wrap">
          <span className="inline-flex items-center gap-1 bg-amber-700/60 px-2 py-0.5 rounded-full text-[11px] font-semibold text-amber-200">
            <Sparkles className="w-3 h-3 text-amber-300" /> सीमित समय ऑफर
          </span>
          <span>400 ग्राम मात्र <strong>₹1499/-</strong></span>
          <span className="hidden sm:inline">•</span>
          <span className="flex items-center gap-1 text-amber-200">
            <ShieldCheck className="w-3.5 h-3.5" /> पूरे भारत में फ्री डिलीवरी + कैश ऑन डिलीवरी (COD)
          </span>
        </div>
      </div>

      {/* Main Nav */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
        {/* Brand identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-white shadow-md shadow-amber-900/10 font-bold text-lg border border-amber-300/30">
            ख
          </div>
          <div>
            <h1 className="font-extrabold text-stone-900 text-base md:text-xl tracking-tight leading-tight">
              {PRODUCT_INFO.name}
            </h1>
            <p className="text-[11px] md:text-xs text-amber-800/80 font-medium">
              पारंपरिक हर्बल वेलनेस फॉर्मूला
            </p>
          </div>
        </div>

        {/* Navigation Anchors for Quick Browse */}
        <nav className="hidden lg:flex items-center gap-5 text-xs font-semibold text-stone-600">
          <a href="#benefits" className="hover:text-amber-700 transition-colors">
            संभावित लाभ
          </a>
          <a href="#ingredients" className="hover:text-amber-700 transition-colors flex items-center gap-1 text-amber-800 font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>
            हर्बल घटक (Ingredients)
          </a>
          <a href="#usage" className="hover:text-amber-700 transition-colors">
            सेवन विधि
          </a>
          <a href="#reviews" className="hover:text-amber-700 transition-colors">
            ग्राहक समीक्षा
          </a>
        </nav>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 md:gap-3">
          <a
            href={`tel:${PRODUCT_INFO.supportPhone}`}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs md:text-sm font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors"
            title="कॉल करें"
          >
            <Phone className="w-3.5 h-3.5 text-stone-600" />
            <span>कॉल सहायता</span>
          </a>

          <button
            onClick={onOrderClick}
            id="header-order-btn"
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white font-bold text-xs md:text-sm rounded-lg shadow-md shadow-amber-700/20 active:scale-95 transition-all cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>अभी ऑर्डर करें</span>
          </button>
        </div>
      </div>
    </header>
  );
};
