import { CustomerReview, ProductOffer, FAQItem } from '../types';

export const PRODUCT_INFO = {
  name: "इमसाक-ए-ख़ास खमीरा",
  englishName: "Imsak-e-Khas Khamira",
  tagline: "पारंपरिक हर्बल फॉर्मूला – प्राकृतिक ऊर्जा, स्टैमिना और समग्र वेलनेस",
  headline: "आज की व्यस्त जीवनशैली में थकान, कम ऊर्जा और तनाव महसूस होना आम बात है।",
  description: "इमसाक-ए-ख़ास खमीरा एक पारंपरिक हर्बल फॉर्मूला है जो शरीर की प्राकृतिक ऊर्जा और समग्र वेलनेस को सपोर्ट करने के लिए बनाया गया है।",
  heritageText: "यह एक पारंपरिक हर्बल खमीरा है जिसे पुराने समय से प्राकृतिक स्वास्थ्य सपोर्ट के लिए उपयोग किया जाता रहा है। ऐसे फॉर्मूले पारंपरिक चिकित्सा पद्धतियों में शरीर की ऊर्जा और संतुलन बनाए रखने के लिए जाने जाते हैं।",
  regularPrice: 2499,
  specialPrice: 1499,
  weight: "400 ग्राम",
  averageRating: 4.9,
  totalReviewsCount: 10,
  disclaimer: "यह एक हर्बल वेलनेस प्रोडक्ट है। यह किसी बीमारी के इलाज या गारंटी का दावा नहीं करता। यदि आप किसी दवा का सेवन कर रहे हैं या कोई स्वास्थ्य समस्या है, तो उपयोग से पहले डॉक्टर से सलाह लें।",
  supportPhone: "+91 98765 43210",
  whatsappNumber: "+919876543210",
  deliveryTimeline: "3 से 5 कार्य दिवस में पूरे भारत में डिलीवरी",
};

export const PRODUCT_OFFERS: ProductOffer[] = [
  {
    id: "pack-1",
    weight: "400 ग्राम (1 जार)",
    quantity: 1,
    price: 1499,
    originalPrice: 2499,
    discountPercentage: 40,
    tag: "सीमित समय का विशेष ऑफर",
    isPopular: true,
    savings: 1000,
  },
  {
    id: "pack-2",
    weight: "800 ग्राम (2 जार - 2 महीने का कोर्स)",
    quantity: 2,
    price: 2699,
    originalPrice: 4998,
    discountPercentage: 46,
    tag: "बेस्ट वैल्यू (अतिरिक्त बचत)",
    isPopular: false,
    savings: 2299,
  },
  {
    id: "pack-3",
    weight: "1200 ग्राम (3 जार - 3 महीने का संपूर्ण कोर्स)",
    quantity: 3,
    price: 3799,
    originalPrice: 7497,
    discountPercentage: 49,
    tag: "सुपर सेवर पैक",
    isPopular: false,
    savings: 3698,
  },
];

export const POTENTIAL_BENEFITS = [
  {
    id: "energy",
    title: "सामान्य ऊर्जा और एक्टिवनेस",
    desc: "शरीर की सामान्य ऊर्जा और दैनिक एक्टिवनेस को प्राकृतिक रूप से सपोर्ट करता है।",
    badge: "ऊर्जा सपोर्ट"
  },
  {
    id: "fatigue",
    title: "दैनिक थकान में कमी",
    desc: "दिनभर के काम के बाद होने वाली थकान और सुस्ती को कम महसूस करने में सहायता करता है।",
    badge: "थकान मुक्ति"
  },
  {
    id: "stamina",
    title: "प्राकृतिक ताकत और स्टैमिना",
    desc: "शरीर की आंतरिक शक्ति और प्राकृतिक स्टैमिना को बनाए रखने में मददगार।",
    badge: "स्टैमिना बूस्ट"
  },
  {
    id: "mental",
    title: "मानसिक संतुलन और रिलैक्सेशन",
    desc: "मानसिक तनाव को नियंत्रित करने, मन को शांत और रिलैक्स रखने में सकारात्मक मदद।",
    badge: "मानसिक शांति"
  },
  {
    id: "confidence",
    title: "आत्मविश्वास और ओवरऑल वेलनेस",
    desc: "आत्मविश्वास में वृद्धि और शरीर के समग्र स्वास्थ्य एवं वेलनेस को बेहतर सपोर्ट।",
    badge: "समग्र स्वास्थ्य"
  }
];

export const WHO_IS_IT_FOR = [
  "जो लोग दैनिक थकान और कम ऊर्जा महसूस करते हैं",
  "जो अपनी एक्टिव लाइफस्टाइल को बेहतर सपोर्ट देना चाहते हैं",
  "जो मानसिक तनाव और व्यस्त दिनचर्या में संतुलन चाहते हैं",
  "जो प्राकृतिक और हर्बल वेलनेस सपोर्ट अपनाना चाहते हैं"
];

export const WHY_CHOOSE_US = [
  {
    title: "पारंपरिक हर्बल फॉर्मूला",
    desc: "प्राचीन यूनानी व आयुर्वेदिक परंपराओं पर आधारित प्रामाणिक रेसिपी।"
  },
  {
    title: "प्राकृतिक सामग्री पर आधारित",
    desc: "शुद्ध शहद, जड़ी-बूटियों और प्राकृतिक अर्क का सुरक्षित मिश्रण।"
  },
  {
    title: "दैनिक उपयोग के लिए आसान",
    desc: "दूध के साथ मात्र 1 चम्मच, किसी झंझट के बिना आसानी से सेवन योग्य।"
  },
  {
    title: "ओवरऑल वेलनेस सपोर्ट",
    desc: "केवल एक हिस्से के लिए नहीं, बल्कि संपूर्ण शरीर की ताकत और संतुलन के लिए।"
  }
];

export const USAGE_STEPS = [
  {
    time: "सुबह का समय",
    title: "सुबह का सेवन",
    instruction: "भोजन या नाश्ते के लगभग आधे घंटे बाद 1 चम्मच गुनगुने या ताजे दूध के साथ।",
    icon: "sunrise"
  },
  {
    time: "शाम / रात का समय",
    title: "शाम का सेवन",
    instruction: "भोजन के लगभग आधे घंटे बाद 1 चम्मच दूध के साथ नियमित रूप से लें।",
    icon: "sunset"
  }
];

export const CUSTOMER_REVIEWS_LIST: CustomerReview[] = [
  {
    id: "rev-1",
    name: "Rajesh Sharma",
    location: "जयपुर, राजस्थान",
    rating: 5,
    date: "14 सितंबर 2026",
    comment: "Bahut acha product hai. Result dekh kar khush hu. Pehle shaam tak thakaan ho jaati thi, ab energy bani rehti hai.",
    verified: true,
    helpfulCount: 24
  },
  {
    id: "rev-2",
    name: "Amit Kumar",
    location: "लखनऊ, उत्तर प्रदेश",
    rating: 5,
    date: "10 सितंबर 2026",
    comment: "Delivery fast thi aur quality bhi achi lagi. Packaging bilkul secret thi aur taste bhi natural herbal hai.",
    verified: true,
    helpfulCount: 19
  },
  {
    id: "rev-3",
    name: "Vikas Singh",
    location: "नई दिल्ली",
    rating: 5,
    date: "5 सितंबर 2026",
    comment: "Paisa vasool product hai. Dudh ke sath roz le raha hu, subah uthte hi freshness feel hoti hai.",
    verified: true,
    helpfulCount: 31
  },
  {
    id: "rev-4",
    name: "Mohammad Imran",
    location: "भोपाल, मध्य प्रदेश",
    rating: 5,
    date: "28 अगस्त 2026",
    comment: "Traditional khameera ka asar wakai lajawab hai. Natural ingredients hone ki wajah se koi side effect nahi laga.",
    verified: true,
    helpfulCount: 15
  },
  {
    id: "rev-5",
    name: "Suresh Patel",
    location: "अहमदाबाद, गुजरात",
    rating: 5,
    date: "21 अगस्त 2026",
    comment: "Pehle bharosa nahi tha lekin 15 din lagatar lene ke baad stamina aur active rehne me bahut sudhaar hua.",
    verified: true,
    helpfulCount: 12
  },
  {
    id: "rev-6",
    name: "Dharmendra Yadav",
    location: "वाराणसी, उत्तर प्रदेश",
    rating: 4,
    date: "18 अगस्त 2026",
    comment: "Product bohot badhiya hai. Bas delivery 1 din late aayi thi, baaki khameera ka taste aur quality ek number hai.",
    verified: true,
    helpfulCount: 8
  },
  {
    id: "rev-7",
    name: "Praveen Rathore",
    location: "इंदौर, मध्य प्रदेश",
    rating: 5,
    date: "12 अगस्त 2026",
    comment: "Work stress bohot rehta tha. Isko start karne ke baad mental relaxation aur daily energy me kafi farq hai.",
    verified: true,
    helpfulCount: 14
  },
  {
    id: "rev-8",
    name: "Manoj Joshi",
    location: "देहरादून, उत्तराखंड",
    rating: 5,
    date: "5 अगस्त 2026",
    comment: "Bilkul authentic herbal formulation. Jar ki packing safe thi aur COD me payment kiya.",
    verified: true,
    helpfulCount: 9
  },
  {
    id: "rev-9",
    name: "Harish Chandra",
    location: "पटना, बिहार",
    rating: 5,
    date: "29 जुलाई 2026",
    comment: "Maine doosra pack bhi order kiya hai. Meri daily routine me isne bohot positive change laya hai.",
    verified: true,
    helpfulCount: 11
  },
  {
    id: "rev-10",
    name: "Sunil Verma",
    location: "कानपुर, उत्तर प्रदेश",
    rating: 5,
    date: "24 जुलाई 2026",
    comment: "100% recommended product. Har kisi ko jo thaka hua feel karta hai, use ek baar zaroor try karna chahiye.",
    verified: true,
    helpfulCount: 17
  }
];

export const FAQS: FAQItem[] = [
  {
    question: "इमसाक-ए-ख़ास खमीरा का सेवन कैसे करना चाहिए?",
    answer: "इसे दिन में दो बार लिया जाता है: सुबह नाश्ते या भोजन के आधे घंटे बाद 1 चम्मच दूध के साथ, और शाम को भोजन के आधे घंटे बाद 1 चम्मच दूध के साथ।"
  },
  {
    question: "क्या कैश ऑन डिलीवरी (COD) उपलब्ध है?",
    answer: "हाँ, पूरे भारत में 100% कैश ऑन डिलीवरी (Cash on Delivery) की सुविधा उपलब्ध है। जब पार्सल आपके घर पहुंचेगा, तभी आपको पैसे देने हैं।"
  },
  {
    question: "डिलीवरी में कितना समय लगता है?",
    answer: "ऑर्डर कन्फर्म होने के 3 से 5 कार्य दिवसों (Working Days) के भीतर पार्सल आपके दिए गए पते पर सुरक्षित और गोपनीय (Discreet) पैकिंग में डिलीवर कर दिया जाता है।"
  },
  {
    question: "क्या इसका कोई साइड इफेक्ट (दुष्प्रभाव) है?",
    answer: "इमसाक-ए-ख़ास खमीरा एक पारंपरिक हर्बल फॉर्मूला है जो प्राकृतिक अवयवों पर आधारित है। सामान्यतः इसका कोई दुष्प्रभाव नहीं होता। हालांकि यदि आपको कोई विशेष स्वास्थ्य समस्या या एलर्जी है तो उपयोग से पहले चिकित्सक से परामर्श लें।"
  },
  {
    question: "एक जार (400 ग्राम) कितने दिन चलेगा?",
    answer: "सुबह और शाम 1-1 चम्मच (लगभग 5-7 ग्राम प्रति खुराक) लेने पर 400 ग्राम का जार लगभग 25 से 30 दिन तक चलता है।"
  },
  {
    question: "क्या पार्सल की पैकिंग गोपनीय रहेगी?",
    answer: "जी बिल्कुल! आपकी गोपनीयता हमारी पहली प्राथमिकता है। पार्सल पर किसी भी प्रकार का उत्पाद नाम या विवरण बाहर नहीं लिखा होता है।"
  }
];

export const RECENT_ORDERS_SIMULATED = [
  { name: "राजेश जी", city: "जयपुर", time: "2 मिनट पहले", pack: "1 जार (400 ग्राम)" },
  { name: "अमित जी", city: "लखनऊ", time: "5 मिनट पहले", pack: "2 जार (800 ग्राम)" },
  { name: "विकास जी", city: "दिल्ली", time: "8 मिनट पहले", pack: "1 जार (400 ग्राम)" },
  { name: "प्रवीण जी", city: "इंदौर", time: "12 मिनट पहले", pack: "3 जार कॉम्बो" },
  { name: "सुनील जी", city: "पटना", time: "15 मिनट पहले", pack: "1 जार (400 ग्राम)" },
  { name: "दीपक जी", city: "कानपुर", time: "19 मिनट पहले", pack: "2 जार कॉम्बो" }
];

export const HERBAL_INGREDIENTS = [
  {
    id: "saffron",
    name: "असली जाफ़रान (केसर)",
    englishName: "Pure Kashmiri Saffron (Zafran)",
    role: "आंतरिक स्फूर्ति, नसों को ताकत और मानसिक ताजगी",
    desc: "प्राचीन यूनानी और आयुर्वेदिक पद्धति में जाफ़रान को सर्वोच्च बलवर्धक माना गया है। यह मस्तिष्क की नसों को सुकून और शरीर में प्राकृतिक गर्माहट व चुस्ती प्रदान करता है।",
    category: "ऊर्जा व स्फूर्ति",
    badge: "शाही घटक (Royal Herb)"
  },
  {
    id: "musli",
    name: "सफ़ेद मूसली",
    englishName: "Safed Musli (Chlorophytum borivilianum)",
    role: "प्राकृतिक स्टैमिना, शक्ति और पौरुष क्षमता",
    desc: "शरीर की आंतरिक कमजोरी और थकान को दूर करने के लिए प्रसिद्ध दिव्य जड़ी-बूटी। यह प्राकृतिक ताकत और लंबे समय तक बने रहने वाले स्टैमिना को बढ़ावा देती है।",
    category: "स्टैमिना व शक्ति",
    badge: "प्राकृतिक रसायन"
  },
  {
    id: "ashwagandha",
    name: "शुद्ध अश्वगंधा",
    englishName: "Pure Ashwagandha (Withania somnifera)",
    role: "दैनिक तनाव से मुक्ति और शारीरिक सहनशक्ति",
    desc: "कोर्टिसोल (तनाव हार्मोन) को संतुलित करने और मांसपेशियों की ताकत बढ़ाने में सहायक। यह दिनभर की मानसिक व शारीरिक थकावट से उबरने में मदद करता है।",
    category: "तनाव मुक्ति",
    badge: "एडाप्टोजेन"
  },
  {
    id: "honey",
    name: "शुद्ध जंगली शहद",
    englishName: "Pure Forest Honey (Shahed Base)",
    role: "प्राकृतिक ऊर्जा का त्वरित स्रोत व सुरक्षित अवशोषण",
    desc: "पारंपरिक खमीरा का मुख्य बेस शुद्ध शहद होता है। यह जड़ी-बूटियों के प्राकृतिक गुणों को सुरक्षित रखता है और शरीर में खमीरे के तत्वों को तुरंत पहुंचाने में मदद करता है।",
    category: "प्राकृतिक बेस",
    badge: "100% शुद्ध बेस"
  },
  {
    id: "kaunch",
    name: "कौंच के बीज",
    englishName: "Kaunch Beej (Mucuna pruriens)",
    role: "तंत्रिका तंत्र की मजबूती और शारीरिक सक्रियता",
    desc: "प्राकृतिक एल-डोपा से समृद्ध यह बीज नसों की कमजोरी को दूर करने, आत्मविश्वास बढ़ाने और आंतरिक वाइटेलिटी को नया जीवन देने में मददगार है।",
    category: "वाइटेलिटी",
    badge: "तंत्रिका शक्ति"
  },
  {
    id: "gokhru",
    name: "छोटा गोखरू",
    englishName: "Gokhru (Tribulus terrestris)",
    role: "मांसपेशियों का पोषण और ऊर्जा संचार",
    desc: "शरीर के सामान्य ऊर्जा स्तर को बनाए रखने और मेटाबॉलिज्म को सुचारु रखने में मदद करता है। यह शरीर में स्फूर्ति और सक्रियता बनाए रखता है।",
    category: "सक्रियता",
    badge: "सहनशक्ति सपोर्ट"
  },
  {
    id: "shatavari",
    name: "शतावरी",
    englishName: "Shatavari (Asparagus racemosus)",
    role: "शरीर की धातुओं का पोषण व इम्युनिटी",
    desc: "शरीर को अंदर से ठंडक व पोषण प्रदान करने वाला प्राकृतिक टॉनिक, जो विभिन्न अंगों के बीच संतुलन और रोग प्रतिरोधक क्षमता को बढ़ाता है।",
    category: "समग्र संतुलन",
    badge: "पोषण वर्धक"
  },
  {
    id: "spices",
    name: "इलायची, दालचीनी व लौंग",
    englishName: "Cardamom, Cinnamon & Clove",
    role: "पाचन सुधार और पोषक तत्वों का तेज अवशोषण",
    desc: "खमीरा के सभी भारी औषधीय तत्वों को पेट में आसानी से पचाने और रक्त प्रवाह में तेजी से शामिल करने के लिए विशेष पाचक अनुपात में मिलाया जाता है।",
    category: "पाचन व अवशोषण",
    badge: "सुगंधित पाचक"
  }
];
