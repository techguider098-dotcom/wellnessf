export interface CustomerReview {
  id: string;
  name: string;
  location: string;
  rating: number;
  date: string;
  comment: string;
  verified: boolean;
  helpfulCount: number;
}

export interface ProductOffer {
  id: string;
  weight: string;
  quantity: number;
  price: number;
  originalPrice: number;
  discountPercentage: number;
  tag?: string;
  isPopular?: boolean;
  savings: number;
}

export interface OrderDetails {
  fullName: string;
  phone: string;
  alternatePhone?: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  selectedOfferId: string;
  paymentMethod: 'COD' | 'UPI';
  notes?: string;
}

export interface FAQItem {
  question: string;
  answer: string;
  category?: string;
}

export interface HerbalIngredient {
  id: string;
  name: string;
  englishName: string;
  role: string;
  desc: string;
  category: string;
  badge?: string;
}
