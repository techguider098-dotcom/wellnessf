import React from 'react';
import { ShoppingBag, Truck } from 'lucide-react';
import { PRODUCT_INFO } from '../data/productData';
import { OfferCountdownTimer } from './OfferCountdownTimer';

interface StickyBottomBarProps {
  onOrderClick: () => void;
}

export const StickyBottomBar: React.FC<StickyBottomBarProps> = ({ onOrderClick }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-amber-200 px-3 py-2 shadow-2xl md:hidden">
      <div className="max-w-md mx-auto flex items-center justify-between gap-3">
        
        {/* Price & urgency info */}
        <div>
          <div className="flex items-center gap-1 mb-0.5">
            <span className="text-[9px] font-bold text-rose-600 uppercase">ऑफर समाप्त:</span>
            <OfferCountdownTimer variant="minimal" className="py-0 px-1 text-[10px]" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-lg font-black text-amber-900 font-mono leading-none">
              ₹{PRODUCT_INFO.specialPrice}/-
            </span>
            <span className="text-xs text-stone-400 line-through leading-none">
              ₹{PRODUCT_INFO.regularPrice}
            </span>
          </div>
          <p className="text-[9px] text-emerald-700 font-bold flex items-center gap-1 mt-0.5">
            <Truck className="w-2.5 h-2.5" /> फ्री COD होम डिलीवरी
          </p>
        </div>

        {/* Action button */}
        <div className="flex-1 max-w-[200px]">
          <button
            onClick={onOrderClick}
            id="mobile-sticky-order-btn"
            className="w-full py-3 px-4 bg-gradient-to-r from-amber-600 to-amber-700 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>ऑर्डर करें (COD)</span>
          </button>
        </div>

      </div>
    </div>
  );
};
