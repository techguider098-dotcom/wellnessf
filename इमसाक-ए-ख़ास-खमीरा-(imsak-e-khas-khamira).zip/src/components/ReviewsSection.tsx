import React, { useState } from 'react';
import { Star, CheckCircle, ThumbsUp, MessageSquarePlus, Filter, X } from 'lucide-react';
import { CUSTOMER_REVIEWS_LIST } from '../data/productData';
import { CustomerReview } from '../types';

export const ReviewsSection: React.FC = () => {
  const [reviews, setReviews] = useState<CustomerReview[]>(CUSTOMER_REVIEWS_LIST);
  const [filterRating, setFilterRating] = useState<number | null>(null);
  const [helpfulClicked, setHelpfulClicked] = useState<Record<string, boolean>>({});
  const [isModalOpen, setIsModalOpen] = useState(false);

  // New review form state
  const [newReviewName, setNewReviewName] = useState('');
  const [newReviewCity, setNewReviewCity] = useState('');
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [newReviewComment, setNewReviewComment] = useState('');
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleHelpful = (id: string) => {
    if (helpfulClicked[id]) return;
    setHelpfulClicked(prev => ({ ...prev, [id]: true }));
    setReviews(prev =>
      prev.map(r => (r.id === id ? { ...r, helpfulCount: r.helpfulCount + 1 } : r))
    );
  };

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewName.trim() || !newReviewComment.trim()) return;

    const newRev: CustomerReview = {
      id: `rev-${Date.now()}`,
      name: newReviewName.trim(),
      location: newReviewCity.trim() || "भारत",
      rating: newReviewRating,
      date: "आज ही पोस्ट किया",
      comment: newReviewComment.trim(),
      verified: true,
      helpfulCount: 0
    };

    setReviews([newRev, ...reviews]);
    setSubmitSuccess(true);
    setTimeout(() => {
      setSubmitSuccess(false);
      setIsModalOpen(false);
      setNewReviewName('');
      setNewReviewCity('');
      setNewReviewComment('');
    }, 1800);
  };

  const filteredReviews = filterRating 
    ? reviews.filter(r => r.rating === filterRating)
    : reviews;

  return (
    <section id="reviews" className="py-12 md:py-16 bg-white border-b border-amber-100/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold mb-3">
            <Star className="w-3.5 h-3.5 fill-current text-amber-600" />
            <span>सत्यापित ग्राहक अनुभव</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-stone-900 tracking-tight">
            Customer Reviews
          </h2>
          <p className="mt-1 text-sm text-stone-600">
            वास्तविक ग्राहकों के प्रामाणिक विचार और परिणाम
          </p>
        </div>

        {/* Rating Summary Card */}
        <div className="bg-amber-50/60 border border-amber-200/80 rounded-3xl p-6 sm:p-8 mb-10 max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            
            {/* Big Score Box */}
            <div className="md:col-span-4 text-center md:border-r md:border-amber-200/80 md:pr-6">
              <div className="text-5xl sm:text-6xl font-black text-stone-900 tracking-tight font-mono">
                4.9
              </div>
              <div className="flex justify-center text-amber-500 my-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-current" />
                ))}
              </div>
              <p className="text-sm font-bold text-amber-950 flex items-center justify-center gap-1">
                <CheckCircle className="w-4 h-4 text-emerald-600" /> 10 Verified Buyers
              </p>
              <p className="text-xs text-stone-500 mt-1">98% ग्राहकों ने 5 स्टार रेटिंग दी</p>
            </div>

            {/* Rating Bars */}
            <div className="md:col-span-5 space-y-2">
              <div className="flex items-center gap-2 text-xs">
                <span className="w-12 text-stone-700 font-semibold">5 Star</span>
                <div className="flex-1 bg-amber-200/40 rounded-full h-2.5 overflow-hidden">
                  <div className="bg-amber-500 h-full rounded-full" style={{ width: '90%' }}></div>
                </div>
                <span className="w-6 text-right text-stone-500">9</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span className="w-12 text-stone-700 font-semibold">4 Star</span>
                <div className="flex-1 bg-amber-200/40 rounded-full h-2.5 overflow-hidden">
                  <div className="bg-amber-500 h-full rounded-full" style={{ width: '10%' }}></div>
                </div>
                <span className="w-6 text-right text-stone-500">1</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span className="w-12 text-stone-700 font-semibold">3 Star</span>
                <div className="flex-1 bg-amber-200/40 rounded-full h-2.5 overflow-hidden">
                  <div className="bg-amber-500 h-full rounded-full" style={{ width: '0%' }}></div>
                </div>
                <span className="w-6 text-right text-stone-500">0</span>
              </div>
            </div>

            {/* Write Review Button */}
            <div className="md:col-span-3 flex flex-col items-center justify-center">
              <button
                onClick={() => setIsModalOpen(true)}
                className="w-full py-3 px-4 bg-white hover:bg-stone-50 text-stone-900 border border-stone-300 font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <MessageSquarePlus className="w-4 h-4 text-amber-600" />
                <span>अपनी समीक्षा लिखें</span>
              </button>
            </div>

          </div>
        </div>

        {/* Filter bar */}
        <div className="flex items-center justify-between gap-3 mb-6 max-w-4xl mx-auto flex-wrap">
          <div className="flex items-center gap-2 text-xs font-semibold text-stone-600">
            <Filter className="w-3.5 h-3.5 text-stone-400" />
            <span>फ़िल्टर करें:</span>
            <button
              onClick={() => setFilterRating(null)}
              className={`px-3 py-1 rounded-full text-xs font-medium cursor-pointer transition-colors ${
                filterRating === null ? 'bg-amber-600 text-white' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              सभी (All)
            </button>
            <button
              onClick={() => setFilterRating(5)}
              className={`px-3 py-1 rounded-full text-xs font-medium cursor-pointer transition-colors ${
                filterRating === 5 ? 'bg-amber-600 text-white' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              5 Star
            </button>
            <button
              onClick={() => setFilterRating(4)}
              className={`px-3 py-1 rounded-full text-xs font-medium cursor-pointer transition-colors ${
                filterRating === 4 ? 'bg-amber-600 text-white' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              4 Star
            </button>
          </div>
          <span className="text-xs text-stone-500 font-medium">
            {filteredReviews.length} समीक्षाएं प्रदर्शित
          </span>
        </div>

        {/* Review Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
          {filteredReviews.map((review) => (
            <div
              key={review.id}
              className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs hover:border-amber-300 hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div>
                    <h3 className="font-extrabold text-stone-900 text-base">
                      {review.name}
                    </h3>
                    <p className="text-[11px] text-stone-500">{review.location}</p>
                  </div>
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    <CheckCircle className="w-3 h-3 text-emerald-600" /> सत्यापित खरीदार
                  </span>
                </div>

                {/* Stars */}
                <div className="flex text-amber-500 mb-2.5">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>

                {/* Comment quote */}
                <blockquote className="text-stone-700 text-sm italic leading-relaxed bg-amber-50/40 p-3 rounded-xl border-l-2 border-amber-400">
                  "{review.comment}"
                </blockquote>
              </div>

              {/* Footer info & helpful button */}
              <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
                <span>{review.date}</span>
                <button
                  onClick={() => handleHelpful(review.id)}
                  disabled={helpfulClicked[review.id]}
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors cursor-pointer ${
                    helpfulClicked[review.id]
                      ? 'bg-emerald-50 text-emerald-700 font-bold'
                      : 'hover:bg-stone-100 text-stone-600'
                  }`}
                >
                  <ThumbsUp className="w-3.5 h-3.5" />
                  <span>उपयोगी ({review.helpfulCount})</span>
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Review Submission Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl relative border border-amber-100">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 p-1 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-extrabold text-stone-900 mb-1">
              अपनी समीक्षा लिखें
            </h3>
            <p className="text-xs text-stone-500 mb-4">
              इमसाक-ए-ख़ास खमीरा के साथ अपना अनुभव साझा करें
            </p>

            {submitSuccess ? (
              <div className="py-8 text-center space-y-2">
                <CheckCircle className="w-12 h-12 text-emerald-600 mx-auto animate-bounce" />
                <h4 className="font-bold text-stone-900 text-base">समीक्षा सफलतापूर्वक दर्ज की गई!</h4>
                <p className="text-xs text-stone-600">आपके अमूल्य फीडबैक के लिए धन्यवाद।</p>
              </div>
            ) : (
              <form onSubmit={handleAddReview} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    आपका पूरा नाम *
                  </label>
                  <input
                    type="text"
                    required
                    value={newReviewName}
                    onChange={(e) => setNewReviewName(e.target.value)}
                    placeholder="उदा. राजेश शर्मा"
                    className="w-full px-3 py-2 text-sm rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    शहर / राज्य
                  </label>
                  <input
                    type="text"
                    value={newReviewCity}
                    onChange={(e) => setNewReviewCity(e.target.value)}
                    placeholder="उदा. लखनऊ, उत्तर प्रदेश"
                    className="w-full px-3 py-2 text-sm rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    रेटिंग *
                  </label>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setNewReviewRating(star)}
                        className="p-1 focus:outline-none cursor-pointer"
                      >
                        <Star
                          className={`w-6 h-6 ${
                            star <= newReviewRating
                              ? 'text-amber-500 fill-current'
                              : 'text-stone-300'
                          }`}
                        />
                      </button>
                    ))}
                    <span className="text-xs font-bold text-amber-800 ml-2">
                      {newReviewRating} स्टार
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    समीक्षा विवरण *
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={newReviewComment}
                    onChange={(e) => setNewReviewComment(e.target.value)}
                    placeholder="उत्पाद के परिणाम, स्वाद और डिलीवरी अनुभव के बारे में बताएं..."
                    className="w-full px-3 py-2 text-sm rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold text-sm rounded-xl shadow-md transition-all cursor-pointer"
                >
                  समीक्षा सबमिट करें
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
