import React from 'react';
import { Sunrise, Sunset, Milk, Check, Clock, Sparkles } from 'lucide-react';

export const UsageSection: React.FC = () => {
  return (
    <section id="usage" className="py-12 md:py-16 bg-white border-b border-amber-100/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold mb-3">
            <span>🥛</span>
            <span>सरल दैनिक सेवन विधि</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-stone-900 tracking-tight">
            सेवन विधि (How to Consume)
          </h2>
          <p className="mt-2 text-sm sm:text-base text-stone-600">
            इमसाक-ए-ख़ास खमीरा का उपयोग अत्यंत सरल है। सर्वोत्तम परिणामों के लिए नीचे दी गई विधि का पालन करें:
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Visual photo of usage */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-full max-w-sm rounded-3xl overflow-hidden shadow-xl border-4 border-amber-100 bg-amber-50">
              <img
                src="/images/product-usage.jpg"
                alt="इमसाक-ए-ख़ास खमीरा दूध के साथ सेवन विधि"
                referrerPolicy="no-referrer"
                className="w-full h-80 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent flex flex-col justify-end p-5 text-white">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-500 text-stone-950 font-bold text-xs rounded-md w-fit mb-1">
                  <Milk className="w-3.5 h-3.5" /> गुनगुने दूध के साथ लें
                </span>
                <p className="text-xs text-amber-100 font-medium">
                  दूध के साथ सेवन करने से पोषक तत्व शरीर में तेजी से अवशोषित होते हैं।
                </p>
              </div>
            </div>
          </div>

          {/* Steps & Timing */}
          <div className="lg:col-span-7 space-y-4">
            
            {/* Morning Step */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-50/40 border border-amber-200/80 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-md">
                <Sunrise className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-800 bg-amber-200/60 px-2 py-0.5 rounded">
                    चरण 1
                  </span>
                  <h3 className="font-extrabold text-stone-900 text-base sm:text-lg">
                    सुबह का सेवन
                  </h3>
                </div>
                <p className="text-sm text-stone-700 font-medium leading-relaxed">
                  भोजन या नाश्ते के लगभग आधे घंटे बाद <strong>1 चम्मच</strong> गुनगुने या ताजे दूध के साथ।
                </p>
              </div>
            </div>

            {/* Evening Step */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-indigo-50/70 to-amber-50/50 border border-indigo-100 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-md">
                <Sunset className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-indigo-800 bg-indigo-100 px-2 py-0.5 rounded">
                    चरण 2
                  </span>
                  <h3 className="font-extrabold text-stone-900 text-base sm:text-lg">
                    शाम का सेवन
                  </h3>
                </div>
                <p className="text-sm text-stone-700 font-medium leading-relaxed">
                  शाम के भोजन के लगभग आधे घंटे बाद <strong>1 चम्मच</strong> दूध के साथ नियमित रूप से लें।
                </p>
              </div>
            </div>

            {/* Note from user prompt */}
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <p className="text-xs sm:text-sm text-emerald-900 font-semibold leading-relaxed">
                "नियमित और संतुलित उपयोग के साथ कई लोग अपनी ऊर्जा और एक्टिवनेस में सकारात्मक बदलाव महसूस करते हैं।"
              </p>
            </div>

            {/* Golden Tips */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs text-stone-600">
              <div className="flex items-center gap-2 bg-stone-50 p-2.5 rounded-lg border border-stone-200">
                <Check className="w-4 h-4 text-amber-600 shrink-0" />
                <span>नियमित 3-4 सप्ताह लें</span>
              </div>
              <div className="flex items-center gap-2 bg-stone-50 p-2.5 rounded-lg border border-stone-200">
                <Check className="w-4 h-4 text-amber-600 shrink-0" />
                <span>पर्याप्त पानी पिएं</span>
              </div>
              <div className="flex items-center gap-2 bg-stone-50 p-2.5 rounded-lg border border-stone-200">
                <Check className="w-4 h-4 text-amber-600 shrink-0" />
                <span>संतुलित भोजन रखें</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
