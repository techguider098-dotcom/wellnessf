import React from 'react';
import { Zap, BatteryCharging, Shield, Sparkles, HeartHandshake, CheckCircle } from 'lucide-react';
import { POTENTIAL_BENEFITS } from '../data/productData';

export const BenefitsSection: React.FC = () => {
  const benefitIcons = [
    <Zap className="w-6 h-6 text-amber-600" />,
    <BatteryCharging className="w-6 h-6 text-emerald-600" />,
    <Shield className="w-6 h-6 text-amber-700" />,
    <Sparkles className="w-6 h-6 text-indigo-600" />,
    <HeartHandshake className="w-6 h-6 text-rose-600" />,
  ];

  return (
    <section id="benefits" className="py-12 md:py-16 bg-white border-y border-amber-100/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-10 md:mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold mb-3">
            <span>🌟</span>
            <span>प्राकृतिक वेलनेस के फायदे</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-stone-900 tracking-tight">
            संभावित लाभ (Key Potential Benefits)
          </h2>
          <p className="mt-2 text-sm sm:text-base text-stone-600">
            इमसाक-ए-ख़ास खमीरा का नियमित और संतुलित उपयोग आपके शरीर को भीतर से सशक्त बनाने में मदद करता है:
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {POTENTIAL_BENEFITS.map((benefit, idx) => (
            <div
              key={benefit.id}
              className={`p-6 rounded-2xl border transition-all duration-300 hover:shadow-lg ${
                idx === 0 
                  ? 'bg-gradient-to-br from-amber-50/90 to-amber-100/50 border-amber-200 md:col-span-2 lg:col-span-1'
                  : 'bg-stone-50/70 hover:bg-white border-stone-200/80 hover:border-amber-200'
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-white shadow-xs border border-amber-100 flex items-center justify-center">
                  {benefitIcons[idx] || <CheckCircle className="w-6 h-6 text-amber-600" />}
                </div>
                <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-amber-100/80 text-amber-900 border border-amber-200/60">
                  {benefit.badge}
                </span>
              </div>

              <div className="flex items-center gap-2 mb-2">
                <span className="text-emerald-600 font-bold text-base">✅</span>
                <h3 className="font-extrabold text-stone-900 text-lg">
                  {benefit.title}
                </h3>
              </div>

              <p className="text-stone-600 text-sm leading-relaxed">
                {benefit.desc}
              </p>
            </div>
          ))}

          {/* Quick takeaway summary card */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-amber-900 to-stone-900 text-white flex flex-col justify-between border border-amber-800/40">
            <div>
              <span className="text-amber-400 text-xs font-bold uppercase tracking-wider">प्रामाणिक दृष्टिकोण</span>
              <h3 className="font-bold text-lg text-white mt-1 mb-2">
                शरीर के प्राकृतिक संतुलन के लिए
              </h3>
              <p className="text-xs text-amber-100/80 leading-relaxed">
                यह कोई रासायनिक उत्तेजक नहीं है, बल्कि पारंपरिक जड़ी-बूटियों का एक पौष्टिक सम्मिश्रण है जो शरीर को धीरे-धीरे नैसर्गिक स्फूर्ति प्रदान करता है।
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-white/10 flex items-center gap-2 text-xs text-amber-300 font-semibold">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>सुरक्षित व संतुलित फॉर्मूलेशन</span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
