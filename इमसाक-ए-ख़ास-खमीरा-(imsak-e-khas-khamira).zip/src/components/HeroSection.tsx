import React, { useState } from 'react';
import { Star, ShieldCheck, CheckCircle2, Truck, RefreshCw, ShoppingCart, Eye, Award } from 'lucide-react';
import { PRODUCT_INFO } from '../data/productData';
import { OfferCountdownTimer } from './OfferCountdownTimer';

interface HeroSectionProps {
  onOrderClick: () => void;
  onReviewScroll: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onOrderClick, onReviewScroll }) => {
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);

  // Images list
  const productImages = [
    {
      src: "/images/khamira_product_jar.jpg",
      title: "इमसाक-ए-ख़ास खमीरा",
      desc: "असली हर्बल खमीरा का प्रीमियम 400 ग्राम जार"
    },
    {
      src: "/images/product-usage.jpg",
      title: "इमसाक-ए-ख़ास खमीरा (सेवन विधि)",
      desc: "चम्मच में शुद्ध हर्बल पेस्ट व गर्म दूध"
    }
  ];

  return (
    <section id="hero-section" className="relative overflow-hidden pt-4 pb-0 md:pt-8 md:pb-0 bg-gradient-to-b from-amber-50/50 via-white to-stone-50">
      {/* Background soft glow circles */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-96 h-96 bg-amber-200/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-amber-300/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* LEFT COLUMN: Product Image Gallery */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="relative w-full max-w-md bg-white p-3 sm:p-4 rounded-3xl border border-amber-100 shadow-xl shadow-amber-950/5">
              
              {/* Product Badge */}
              <div className="absolute top-6 left-6 z-20 bg-amber-900/90 backdrop-blur-md text-amber-100 text-[11px] sm:text-xs font-bold px-3 py-1.5 rounded-full shadow-md flex items-center gap-1.5 border border-amber-500/30">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                सीमित समय का विशेष ऑफर
              </div>

              {/* Discount Tag */}
              <div className="absolute top-6 right-6 z-20 bg-rose-600 text-white text-xs sm:text-sm font-extrabold px-3 py-1.5 rounded-xl shadow-md transform rotate-2">
                40% छूट
              </div>

              {/* Main Image Box */}
              <div 
                className="relative aspect-square w-full rounded-2xl overflow-hidden bg-amber-50/50 border border-amber-100/60 cursor-pointer group"
                onClick={() => setIsZoomed(!isZoomed)}
              >
                <img
                  id="hero-product-main-img"
                  src={productImages[activeImageIndex].src}
                  alt="इमसाक-ए-ख़ास खमीरा (Imsak-e-Khas Khamira) - ओरिजिनल ब्रांड लेबल"
                  title="इमसाक-ए-ख़ास खमीरा - ऑफिशियल ब्रांड लेबल"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />

                {/* Official Branding Seal */}
                <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 bg-amber-950/90 backdrop-blur-md text-amber-200 border border-amber-400/50 px-2.5 py-1 rounded-lg shadow-md pointer-events-none">
                  <Award className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span className="text-[10px] sm:text-[11px] font-bold tracking-wide uppercase text-amber-100">
                    ओरिजिनल ब्रांड मुहर
                  </span>
                </div>

                {/* Product Name Official Branding Label */}
                <div className="absolute bottom-2.5 left-2.5 right-2.5 z-10 bg-gradient-to-r from-stone-950/95 via-amber-950/95 to-stone-950/95 backdrop-blur-md text-white border-2 border-amber-500/60 px-3 py-2 rounded-xl shadow-xl flex items-center justify-between pointer-events-none">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-gradient-to-br from-amber-400 to-amber-700 flex items-center justify-center text-amber-950 font-black text-xs sm:text-sm shrink-0 shadow-sm border border-amber-300">
                      IK
                    </div>
                    <div className="truncate">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-amber-300 font-extrabold text-xs sm:text-sm tracking-wide drop-shadow-xs">
                          इमसाक-ए-ख़ास खमीरा
                        </span>
                        <span className="bg-amber-500/30 text-amber-200 border border-amber-400/50 text-[9px] font-bold px-1.5 py-0.2 rounded whitespace-nowrap">
                          ब्रांड लेबल
                        </span>
                      </div>
                      <p className="text-stone-300 text-[10px] font-medium truncate">
                        Imsak-e-Khas Khamira • 400 ग्राम
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 pl-2 shrink-0">
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/40 px-1.5 py-0.5 rounded">
                      100% असली
                    </span>
                  </div>
                </div>

                {/* Enlarge Hint */}
                <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-sm text-white text-[10px] px-2 py-1 rounded-md flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                  <Eye className="w-3 h-3" /> बड़ा करें
                </div>
              </div>

              {/* Thumbnails */}
              <div className="grid grid-cols-2 gap-3 mt-3">
                {productImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`flex items-center gap-2 p-2 rounded-xl border text-left transition-all ${
                      activeImageIndex === idx
                        ? 'border-amber-600 bg-amber-50/80 shadow-xs'
                        : 'border-stone-200 bg-stone-50 hover:bg-white'
                    }`}
                  >
                    <img
                      src={img.src}
                      alt={img.title}
                      referrerPolicy="no-referrer"
                      className="w-12 h-12 rounded-lg object-cover border border-amber-200"
                    />
                    <div className="overflow-hidden">
                      <p className="text-xs font-bold text-stone-900 truncate">{img.title}</p>
                      <p className="text-[10px] text-stone-500 truncate">{img.desc}</p>
                    </div>
                  </button>
                ))}
              </div>

              {/* Quality & Trust Badges Strip */}
              <div className="mt-4 pt-3 border-t border-amber-100 grid grid-cols-3 gap-2 text-center">
                <div className="flex flex-col items-center">
                  <span className="text-base">🌿</span>
                  <span className="text-[11px] font-semibold text-stone-700 mt-0.5">100% हर्बल</span>
                  <span className="text-[9px] text-stone-500">पारंपरिक विधि</span>
                </div>
                <div className="flex flex-col items-center border-x border-amber-100">
                  <span className="text-base">🛡️</span>
                  <span className="text-[11px] font-semibold text-stone-700 mt-0.5">सुरक्षित पैकिंग</span>
                  <span className="text-[9px] text-stone-500">गोपनीय पार्सल</span>
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-base">🚚</span>
                  <span className="text-[11px] font-semibold text-stone-700 mt-0.5">फ्री होम डिलीवरी</span>
                  <span className="text-[9px] text-stone-500">कैश ऑन डिलीवरी</span>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: Product Details & Fast Conversion */}
          <div className="lg:col-span-7 flex flex-col space-y-4">
            
            {/* Top Review Rating Pill */}
            <div className="flex items-center gap-3 flex-wrap">
              <button 
                onClick={onReviewScroll}
                className="inline-flex items-center gap-2 bg-amber-100/80 hover:bg-amber-100 border border-amber-300/80 text-amber-950 px-3 py-1 rounded-full text-xs font-bold transition-colors cursor-pointer"
              >
                <div className="flex text-amber-500">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-current" />
                  ))}
                </div>
                <span>4.9 / 5.0</span>
                <span className="text-amber-800 text-[11px] font-medium">(10+ सत्यापित ग्राहक समीक्षाएं)</span>
              </button>

              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> 100% ओरिजिनल प्रोडक्ट
              </span>
            </div>

            {/* Product Title */}
            <div>
              <h1 className="text-2xl sm:text-4xl font-extrabold text-stone-900 tracking-tight leading-tight">
                {PRODUCT_INFO.name}
              </h1>
              <p className="text-base sm:text-lg font-semibold text-amber-800 mt-1">
                {PRODUCT_INFO.tagline}
              </p>
            </div>

            {/* Hook text from user prompt */}
            <div className="bg-amber-50/90 border-l-4 border-amber-600 p-3.5 rounded-r-xl">
              <p className="text-stone-800 text-sm md:text-base leading-relaxed font-medium">
                "{PRODUCT_INFO.headline} <strong className="text-amber-950 font-bold">{PRODUCT_INFO.description}</strong>"
              </p>
            </div>

            {/* Key bullet takeaways */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm text-stone-700 py-1">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>प्राकृतिक ऊर्जा और एक्टिवनेस को सपोर्ट</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>दैनिक थकान व कमजोरी कम करने में सहायता</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>प्राकृतिक ताकत और स्टैमिना को बढ़ावा</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>मानसिक संतुलन और ओवरऑल वेलनेस</span>
              </div>
            </div>

            {/* PRICING & SPECIAL OFFER BOX */}
            <div className="bg-gradient-to-br from-amber-950 via-stone-900 to-amber-950 text-white p-4 sm:p-5 rounded-2xl shadow-xl border border-amber-700/40 relative">
              {/* Dynamic Countdown Urgency Strip */}
              <OfferCountdownTimer variant="compact" showStockAlert={false} className="mb-3.5 bg-black/40 border-amber-500/30" />

              <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <span className="text-amber-400 font-bold text-xs sm:text-sm uppercase tracking-wider flex items-center gap-1.5">
                    ✨ {PRODUCT_INFO.weight} स्पेशल पैक
                  </span>
                  <span className="bg-rose-500 text-white text-[10px] sm:text-xs font-bold px-2 py-0.5 rounded-md">
                    बचत ₹1000/-
                  </span>
                </div>
                
                <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                  ✓ स्टॉक में उपलब्ध (केवल 11 बचे)
                </span>
              </div>

              {/* Price Numbers */}
              <div className="flex items-baseline gap-3 my-3">
                <span className="text-3xl sm:text-4xl font-extrabold text-amber-300 font-mono">
                  ₹{PRODUCT_INFO.specialPrice}/-
                </span>
                <span className="text-stone-400 line-through text-lg font-medium">
                  ₹{PRODUCT_INFO.regularPrice}
                </span>
                <span className="text-xs text-emerald-300 font-semibold bg-emerald-950/80 px-2 py-1 rounded-md border border-emerald-500/30">
                  सभी टैक्स सहित
                </span>
              </div>

              <p className="text-xs text-amber-100/90 mb-4 flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                <span>डिलीवरी फ्री है और भुगतान सामान मिलने पर (Cash on Delivery) करें।</span>
              </p>

              {/* CTA Action Button */}
              <div>
                <button
                  onClick={onOrderClick}
                  id="hero-order-cod-btn"
                  className="w-full flex items-center justify-center gap-2 py-4 px-6 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-black text-base sm:text-lg rounded-xl shadow-xl shadow-amber-500/25 active:scale-[0.98] transition-all cursor-pointer border border-amber-300"
                >
                  <ShoppingCart className="w-5 h-5 text-stone-950" />
                  <span>कैश ऑन डिलीवरी (COD) ऑर्डर करें</span>
                </button>
              </div>
            </div>

            {/* Quick trust reassurance */}
            <div className="flex items-center justify-between text-[11px] sm:text-xs text-stone-600 pt-1 px-1">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-700" /> गोपनीय पैकेजिंग
              </span>
              <span className="flex items-center gap-1">
                <RefreshCw className="w-3.5 h-3.5 text-amber-700" /> प्रामाणिक हर्बल सामग्री
              </span>
              <span className="flex items-center gap-1">
                <Truck className="w-3.5 h-3.5 text-amber-700" /> 3-5 दिन में डिलीवरी
              </span>
            </div>

          </div>

        </div>
      </div>

      {/* Subtle Ornamental Gold-Tone Rule & Wave Divider */}
      <div className="relative w-full pt-8 pb-0 mt-6 sm:mt-8 overflow-hidden pointer-events-none select-none">
        {/* Ornamental Gold Motif Horizontal Rule */}
        <div className="max-w-3xl mx-auto px-6 flex items-center justify-center gap-3 mb-5">
          <div className="h-px flex-1 bg-gradient-to-r from-transparent via-amber-300 to-amber-500/70" />
          <div className="flex items-center gap-1.5 text-amber-600">
            <span className="w-1.5 h-1.5 rotate-45 bg-amber-400/80 rounded-[1px]" />
            <span className="w-2.5 h-2.5 rotate-45 bg-gradient-to-br from-amber-400 to-amber-600 rounded-[2px] shadow-xs" />
            <span className="w-1.5 h-1.5 rotate-45 bg-amber-400/80 rounded-[1px]" />
          </div>
          <div className="h-px flex-1 bg-gradient-to-l from-transparent via-amber-300 to-amber-500/70" />
        </div>

        {/* Gentle Wave Curve Transition into the Benefits Section */}
        <div className="w-full overflow-hidden leading-none -mb-[1px]">
          <svg
            className="relative block w-full h-8 sm:h-12 text-white"
            viewBox="0 0 1200 120"
            preserveAspectRatio="none"
            aria-hidden="true"
          >
            {/* Subtle warm amber undertone wave */}
            <path
              d="M0,15 C220,65 440,-5 680,45 C920,95 1080,20 1200,45 L1200,120 L0,120 Z"
              fill="#fef3c7"
              fillOpacity="0.45"
            />
            {/* Crisp white wave matching benefits section background */}
            <path
              d="M0,45 C190,95 410,25 640,70 C870,115 1050,45 1200,75 L1200,120 L0,120 Z"
              fill="#ffffff"
            />
          </svg>
        </div>
      </div>

      {/* Lightbox Modal if user wants to see image in full resolution */}
      {isZoomed && (
        <div 
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 cursor-pointer"
          onClick={() => setIsZoomed(false)}
        >
          <div className="relative max-w-2xl w-full bg-white rounded-3xl overflow-hidden p-3 sm:p-4 shadow-2xl border border-amber-200">
            <img
              src={productImages[activeImageIndex].src}
              alt={productImages[activeImageIndex].title}
              referrerPolicy="no-referrer"
              className="w-full h-auto object-contain max-h-[75vh] rounded-2xl border border-amber-100 shadow-sm bg-stone-50"
            />
            <div className="pt-3 pb-1 text-center">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-950 text-xs font-bold mb-1 border border-amber-300/80">
                <span>{productImages[activeImageIndex].title}</span>
              </div>
              <p className="text-xs text-stone-500">{productImages[activeImageIndex].desc}</p>
              <p className="text-[11px] text-amber-800 font-medium mt-1">बंद करने के लिए कहीं भी क्लिक करें (Click anywhere to close)</p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
