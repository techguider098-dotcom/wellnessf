import React from 'react';
import { CheckCircle2, Sparkles, Tag, ShieldCheck } from 'lucide-react';
import { PRODUCT_OFFERS } from '../data/productData';
import { ProductOffer } from '../types';
import { OfferCountdownTimer } from './OfferCountdownTimer';

interface OfferSelectorProps {
  selectedOffer: ProductOffer;
  onSelectOffer: (offer: ProductOffer) => void;
}

export const OfferSelector: React.FC<OfferSelectorProps> = ({ selectedOffer, onSelectOffer }) => {
  return (
    <div className="space-y-4">
      {/* Dynamic Countdown Urgency Timer */}
      <OfferCountdownTimer variant="detailed" showStockAlert={true} />

      <div className="flex items-center justify-between pt-1">
        <label className="text-sm font-bold text-stone-900 flex items-center gap-1.5">
          <Tag className="w-4 h-4 text-amber-600" />
          <span>पैक और मात्रा चुनें (Select Package)</span>
        </label>
        <span className="text-xs text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
          फ्री डिलीवरी + COD
        </span>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {PRODUCT_OFFERS.map((offer) => {
          const isSelected = selectedOffer.id === offer.id;
          return (
            <div
              key={offer.id}
              onClick={() => onSelectOffer(offer)}
              className={`relative p-4 rounded-2xl border-2 transition-all cursor-pointer ${
                isSelected
                  ? 'border-amber-600 bg-amber-50/70 shadow-md ring-1 ring-amber-600'
                  : 'border-stone-200 bg-white hover:border-amber-300 hover:bg-stone-50/50'
              }`}
            >
              {/* Highlight Tag */}
              {offer.tag && (
                <div className="absolute -top-2.5 right-4 bg-gradient-to-r from-amber-600 to-amber-700 text-white text-[10px] font-extrabold px-2.5 py-0.5 rounded-full shadow-xs flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-200" />
                  <span>{offer.tag}</span>
                </div>
              )}

              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                    isSelected ? 'border-amber-600 bg-amber-600 text-white' : 'border-stone-400'
                  }`}>
                    {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                  </div>

                  <div>
                    <h3 className="font-extrabold text-stone-900 text-sm sm:text-base">
                      {offer.weight}
                    </h3>
                    <p className="text-xs text-stone-500 font-medium">
                      M.R.P. <span className="line-through">₹{offer.originalPrice}</span> • छूट: {offer.discountPercentage}%
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-lg sm:text-xl font-black text-amber-900 font-mono">
                    ₹{offer.price}/-
                  </div>
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                    बचत ₹{offer.savings}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
