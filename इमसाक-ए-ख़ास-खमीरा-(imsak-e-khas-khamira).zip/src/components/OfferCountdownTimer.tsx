import React, { useState, useEffect } from 'react';
import { Clock, Flame, Zap, AlertTriangle, TrendingUp } from 'lucide-react';

interface OfferCountdownTimerProps {
  variant?: 'detailed' | 'compact' | 'minimal';
  className?: string;
  showStockAlert?: boolean;
}

export const OfferCountdownTimer: React.FC<OfferCountdownTimerProps> = ({
  variant = 'detailed',
  className = '',
  showStockAlert = true,
}) => {
  // Store or calculate a realistic expiration target in localStorage to persist across refreshes
  const [timeLeft, setTimeLeft] = useState<{ hours: number; minutes: number; seconds: number }>({
    hours: 2,
    minutes: 47,
    seconds: 35,
  });

  useEffect(() => {
    // 2 hours 48 minutes target from first load
    const STORAGE_KEY = 'imsak_offer_expiry';
    let targetTime = localStorage.getItem(STORAGE_KEY);

    if (!targetTime || isNaN(Number(targetTime)) || Number(targetTime) <= Date.now()) {
      const newTarget = Date.now() + (2 * 60 * 60 + 47 * 60 + 35) * 1000;
      localStorage.setItem(STORAGE_KEY, newTarget.toString());
      targetTime = newTarget.toString();
    }

    const calculateRemaining = () => {
      const now = Date.now();
      const diff = Math.max(0, Number(targetTime) - now);

      if (diff <= 0) {
        // Reset a slight window for ongoing visitors to maintain urgency
        const resetTarget = Date.now() + (1 * 60 * 60 + 30 * 60) * 1000;
        localStorage.setItem(STORAGE_KEY, resetTarget.toString());
        return { hours: 1, minutes: 30, seconds: 0 };
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      return { hours, minutes, seconds };
    };

    setTimeLeft(calculateRemaining());

    const interval = setInterval(() => {
      setTimeLeft(calculateRemaining());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatDigit = (num: number) => String(num).padStart(2, '0');

  // Minimal variant (used in small badges)
  if (variant === 'minimal') {
    return (
      <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-rose-950/80 border border-rose-500/40 text-rose-200 text-xs font-mono font-bold ${className}`}>
        <Clock className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
        <span>
          {formatDigit(timeLeft.hours)}:{formatDigit(timeLeft.minutes)}:{formatDigit(timeLeft.seconds)}
        </span>
      </div>
    );
  }

  // Compact variant (used inside hero pricing card or summary boxes)
  if (variant === 'compact') {
    return (
      <div className={`rounded-xl bg-gradient-to-r from-amber-950 via-rose-950 to-stone-900 p-3 border border-amber-500/30 text-white ${className}`}>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
            </span>
            <div className="text-left">
              <p className="text-[11px] font-bold text-amber-300 flex items-center gap-1">
                <Zap className="w-3 h-3 text-amber-400 fill-amber-400" />
                ₹1499 विशेष छूट जल्द समाप्त हो रही है!
              </p>
              <p className="text-[10px] text-stone-300">
                सीमित समय ऑफर – इसके बाद कीमत ₹2499/- होगी
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 text-center font-mono">
            <div className="bg-black/60 px-2 py-1 rounded-md border border-amber-500/30">
              <span className="text-xs font-black text-amber-200">{formatDigit(timeLeft.hours)}</span>
              <span className="block text-[8px] text-stone-400">घंटे</span>
            </div>
            <span className="text-amber-400 font-bold">:</span>
            <div className="bg-black/60 px-2 py-1 rounded-md border border-amber-500/30">
              <span className="text-xs font-black text-amber-200">{formatDigit(timeLeft.minutes)}</span>
              <span className="block text-[8px] text-stone-400">मिनट</span>
            </div>
            <span className="text-amber-400 font-bold">:</span>
            <div className="bg-black/60 px-2 py-1 rounded-md border border-rose-500/40 animate-pulse">
              <span className="text-xs font-black text-rose-300">{formatDigit(timeLeft.seconds)}</span>
              <span className="block text-[8px] text-rose-300">सेकंड</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Detailed variant (Primary high-converting banner for Offer Section & Checkout)
  return (
    <div
      id="offer-countdown-banner"
      className={`relative overflow-hidden rounded-2xl bg-gradient-to-br from-stone-900 via-amber-950 to-stone-900 text-white p-4 sm:p-5 border-2 border-amber-500/50 shadow-xl shadow-amber-950/20 ${className}`}
    >
      {/* Decorative ambient background accents */}
      <div className="absolute -top-12 -right-12 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-rose-600/15 rounded-full blur-2xl pointer-events-none" />

      {/* Header with live pulse badge */}
      <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3.5 border-b border-amber-500/20">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-rose-500 to-amber-600 flex items-center justify-center text-white shadow-md shadow-rose-900/40 shrink-0">
            <Flame className="w-5 h-5 text-amber-100 animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="inline-flex items-center gap-1 text-[10px] sm:text-[11px] font-black uppercase tracking-wider bg-rose-600 text-white px-2 py-0.5 rounded-full shadow-xs">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping"></span>
                सीमित समय का ऑफर (Limited Time Deal)
              </span>
              <span className="text-[11px] font-bold text-amber-400">
                बचत ₹1000/- (40% OFF)
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-black text-white mt-1 leading-tight tracking-tight">
              ₹1499 का विशेष ऑफर मूल्य जल्द समाप्त हो रहा है!
            </h3>
            <p className="text-xs text-amber-200/80 font-medium">
              समय समाप्त होने पर कीमत वापस सामान्य M.R.P. <span className="line-through text-stone-400">₹2499/-</span> हो जाएगी।
            </p>
          </div>
        </div>

        {/* Big Digit Countdown Display */}
        <div className="flex items-center justify-center sm:justify-end gap-1.5 shrink-0 self-center sm:self-auto font-mono">
          {/* Hours */}
          <div className="flex flex-col items-center">
            <div className="w-12 sm:w-14 h-12 sm:h-14 bg-stone-950/90 rounded-xl border border-amber-500/40 flex items-center justify-center shadow-inner">
              <span className="text-xl sm:text-2xl font-black text-amber-300 tracking-wider">
                {formatDigit(timeLeft.hours)}
              </span>
            </div>
            <span className="text-[9px] sm:text-[10px] text-amber-300/80 font-sans font-semibold mt-1">
              घंटे (Hrs)
            </span>
          </div>

          <span className="text-amber-400 font-bold text-lg mb-4">:</span>

          {/* Minutes */}
          <div className="flex flex-col items-center">
            <div className="w-12 sm:w-14 h-12 sm:h-14 bg-stone-950/90 rounded-xl border border-amber-500/40 flex items-center justify-center shadow-inner">
              <span className="text-xl sm:text-2xl font-black text-amber-300 tracking-wider">
                {formatDigit(timeLeft.minutes)}
              </span>
            </div>
            <span className="text-[9px] sm:text-[10px] text-amber-300/80 font-sans font-semibold mt-1">
              मिनट (Mins)
            </span>
          </div>

          <span className="text-amber-400 font-bold text-lg mb-4">:</span>

          {/* Seconds with pulsing glow */}
          <div className="flex flex-col items-center">
            <div className="w-12 sm:w-14 h-12 sm:h-14 bg-stone-950/90 rounded-xl border-2 border-rose-500/70 flex items-center justify-center shadow-md shadow-rose-900/30">
              <span className="text-xl sm:text-2xl font-black text-rose-400 tracking-wider animate-pulse">
                {formatDigit(timeLeft.seconds)}
              </span>
            </div>
            <span className="text-[9px] sm:text-[10px] text-rose-400 font-sans font-semibold mt-1">
              सेकंड (Secs)
            </span>
          </div>
        </div>
      </div>

      {/* Urgency Progress Bar & Stock Indicator */}
      {showStockAlert && (
        <div className="relative z-10 pt-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
          <div className="flex items-center gap-2 text-amber-200">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 animate-pulse" />
            <span className="font-bold text-stone-100">
              आज के स्पेशल कोटा में केवल <strong className="text-amber-400 font-extrabold underline decoration-amber-400">11 जार शेष</strong> हैं!
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-28 sm:w-36 h-2.5 bg-stone-950 rounded-full overflow-hidden border border-amber-500/30 p-0.5">
              <div className="h-full bg-gradient-to-r from-amber-500 to-rose-500 rounded-full w-[88%] animate-pulse" />
            </div>
            <span className="text-[11px] font-extrabold text-amber-300 font-mono">
              88% क्लेम हो चुका
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
