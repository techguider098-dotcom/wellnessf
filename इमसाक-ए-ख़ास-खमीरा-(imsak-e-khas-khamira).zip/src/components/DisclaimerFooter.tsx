import React from 'react';
import { AlertTriangle, ShieldCheck, Heart, Phone, Mail, ArrowUp } from 'lucide-react';
import { PRODUCT_INFO } from '../data/productData';

export const DisclaimerFooter: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-stone-900 text-stone-300 pt-12 pb-24 md:pb-12 border-t border-amber-900/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* CRITICAL DISCLAIMER / NOTE BOX (From user prompt) */}
        <div className="bg-amber-950/80 border border-amber-600/40 rounded-2xl p-5 sm:p-6 text-amber-100 flex items-start gap-4">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
          </div>
          <div className="space-y-1">
            <h4 className="font-extrabold text-amber-300 text-sm sm:text-base flex items-center gap-1.5">
              <span>⚠️ महत्वपूर्ण सूचना व डिस्क्लेमर (Disclaimer):</span>
            </h4>
            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
              "{PRODUCT_INFO.disclaimer}"
            </p>
          </div>
        </div>

        {/* Footer Columns */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 text-xs sm:text-sm">
          
          {/* Brand Col */}
          <div className="md:col-span-5 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold text-sm">
                ख
              </div>
              <span className="font-extrabold text-white text-lg tracking-tight">
                {PRODUCT_INFO.name}
              </span>
            </div>
            <p className="text-stone-400 text-xs leading-relaxed max-w-sm">
              प्राचीन भारतीय व यूनानी परंपराओं पर आधारित विशुद्ध हर्बल खमीरा। शरीर की आंतरिक ऊर्जा, स्टैमिना और समग्र वेलनेस को प्राकृतिक रूप से पोषण प्रदान करने हेतु तैयार किया गया है।
            </p>
            <div className="flex items-center gap-2 pt-2 text-stone-400 text-xs">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>100% प्रामाणिक सामग्री • गोपनीय डिलीवरी</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-2">
            <h5 className="font-bold text-white text-sm uppercase tracking-wider text-amber-400">
              त्वरित नेविगेशन
            </h5>
            <ul className="space-y-1.5 text-stone-400 text-xs">
              <li>
                <a href="#benefits" className="hover:text-amber-300 transition-colors">संभावित लाभ</a>
              </li>
              <li>
                <a href="#usage" className="hover:text-amber-300 transition-colors">सेवन विधि (How to use)</a>
              </li>
              <li>
                <a href="#reviews" className="hover:text-amber-300 transition-colors">ग्राहक समीक्षाएं (Reviews)</a>
              </li>
              <li>
                <a href="#faqs" className="hover:text-amber-300 transition-colors">अक्सर पूछे जाने वाले सवाल (FAQs)</a>
              </li>
              <li>
                <a href="#order-form-section" className="hover:text-amber-300 transition-colors">ऑर्डर फॉर्म (COD)</a>
              </li>
            </ul>
          </div>

          {/* Help & Contact */}
          <div className="md:col-span-4 space-y-2">
            <h5 className="font-bold text-white text-sm uppercase tracking-wider text-amber-400">
              ग्राहक सहायता (Support)
            </h5>
            <p className="text-stone-400 text-xs">
              सोमवार से शनिवार (सुबह 10:00 से शाम 7:00 बजे तक)
            </p>
            <div className="space-y-1.5 pt-1 text-xs">
              <div className="flex items-center gap-2 text-stone-300">
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>फोन: {PRODUCT_INFO.supportPhone}</span>
              </div>
              <div className="flex items-center gap-2 text-stone-300">
                <Mail className="w-3.5 h-3.5 text-amber-400" />
                <span>ईमेल: support@khamirawellness.in</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="pt-6 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <p>© {new Date().getFullYear()} {PRODUCT_INFO.name}. सर्वाधिकार सुरक्षित (All Rights Reserved).</p>
          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 text-amber-400 hover:text-amber-300 transition-colors cursor-pointer"
          >
            <span>शीर्ष पर जाएं</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
};
