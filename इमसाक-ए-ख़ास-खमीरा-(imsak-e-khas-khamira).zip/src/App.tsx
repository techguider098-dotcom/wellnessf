/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { BenefitsSection } from './components/BenefitsSection';
import { HeritageSection } from './components/HeritageSection';
import { IngredientsSection } from './components/IngredientsSection';
import { UsageSection } from './components/UsageSection';
import { WhoIsItFor } from './components/WhoIsItFor';
import { ReviewsSection } from './components/ReviewsSection';
import { OrderForm } from './components/OrderForm';
import { FAQSection } from './components/FAQSection';
import { DisclaimerFooter } from './components/DisclaimerFooter';
import { StickyBottomBar } from './components/StickyBottomBar';
import { RecentOrderToast } from './components/RecentOrderToast';

export default function App() {
  const scrollToOrderForm = () => {
    const el = document.getElementById('order-form-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToReviews = () => {
    const el = document.getElementById('reviews');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FFFDF9] text-stone-800 font-sans selection:bg-amber-200 selection:text-amber-900">
      {/* Top Header & Announcements */}
      <Header onOrderClick={scrollToOrderForm} />

      <main className="flex-1">
        {/* Hero Section with Product Showcase & Quick Order */}
        <HeroSection 
          onOrderClick={scrollToOrderForm} 
          onReviewScroll={scrollToReviews} 
        />

        {/* 🌟 संभावित लाभ (Potential Benefits) */}
        <BenefitsSection />

        {/* 🌿 पारंपरिक हर्बल फॉर्मूला (Heritage & Formulation) */}
        <HeritageSection />

        {/* 🌱 मुख्य प्राकृतिक हर्बल घटक (Key Herbal Ingredients & Trust) */}
        <IngredientsSection />

        {/* 🥛 सेवन विधि (Usage Instructions & Photo) */}
        <UsageSection />

        {/* 🎯 यह किसके लिए उपयोगी हो सकता है? & 🛡️ क्यों चुनें? */}
        <WhoIsItFor onOrderClick={scrollToOrderForm} />

        {/* Customer Reviews & Testimonials */}
        <ReviewsSection />

        {/* Cash on Delivery (COD) Order Booking Form */}
        <OrderForm />

        {/* Frequently Asked Questions */}
        <FAQSection />
      </main>

      {/* ⚠️ महत्वपूर्ण नोट & Footer */}
      <DisclaimerFooter />

      {/* Mobile Sticky Order Bar */}
      <StickyBottomBar onOrderClick={scrollToOrderForm} />

      {/* Recent Activity Social Proof Notification */}
      <RecentOrderToast />
    </div>
  );
}
