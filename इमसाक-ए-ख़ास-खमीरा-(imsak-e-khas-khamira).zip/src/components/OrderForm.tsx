import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Truck, 
  ShieldCheck, 
  CheckCircle2, 
  Lock, 
  Phone, 
  MapPin, 
  User, 
  Clock, 
  Check, 
  Sparkles,
  ArrowRight,
  X
} from 'lucide-react';
import { OfferSelector } from './OfferSelector';
import { PRODUCT_OFFERS, PRODUCT_INFO } from '../data/productData';
import { ProductOffer } from '../types';

interface OrderFormProps {
  onOrderSuccess?: () => void;
}

export const OrderForm: React.FC<OrderFormProps> = ({ onOrderSuccess }) => {
  const [selectedOffer, setSelectedOffer] = useState<ProductOffer>(PRODUCT_OFFERS[0]);
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [stateName, setStateName] = useState('उत्तर प्रदेश');
  const [pincode, setPincode] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'UPI'>('COD');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderSuccessData, setOrderSuccessData] = useState<{
    orderId: string;
    name: string;
    total: number;
    offer: string;
    payment: string;
  } | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !phone.trim() || !address.trim() || !pincode.trim()) {
      alert("कृपया सभी आवश्यक विवरण (नाम, मोबाइल नंबर, पता और पिनकोड) भरें।");
      return;
    }

    if (phone.replace(/[^0-9]/g, '').length < 10) {
      alert("कृपया 10 अंकों का सही मोबाइल नंबर दर्ज करें।");
      return;
    }

    setIsSubmitting(true);

    // Simulate fast order processing
    setTimeout(() => {
      const generatedId = "IK-" + Math.floor(100000 + Math.random() * 900000);
      setOrderSuccessData({
        orderId: generatedId,
        name: fullName,
        total: selectedOffer.price,
        offer: selectedOffer.weight,
        payment: paymentMethod === 'COD' ? 'कैश ऑन डिलीवरी (सामान मिलने पर नकद)' : 'ऑनलाइन / UPI',
      });
      setIsSubmitting(false);
      if (onOrderSuccess) onOrderSuccess();
    }, 1000);
  };

  const handleReset = () => {
    setOrderSuccessData(null);
    setFullName('');
    setPhone('');
    setAddress('');
    setPincode('');
    setCity('');
  };

  const indianStates = [
    "उत्तर प्रदेश", "बिहार", "मध्य प्रदेश", "राजस्थान", "दिल्ली (NCR)", 
    "महाराष्ट्र", "गुजरात", "हरियाणा", "पंजाब", "उत्तराखंड", 
    "झारखंड", "छत्तीसगढ़", "पश्चिम बंगाल", "अन्य राज्य"
  ];

  return (
    <section id="order-form-section" className="py-12 md:py-16 bg-gradient-to-b from-amber-50/70 via-stone-50 to-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold mb-2">
            <Truck className="w-3.5 h-3.5 text-emerald-700" />
            <span>पूरे भारत में फ्री होम डिलीवरी</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-stone-900 tracking-tight">
            कैश ऑन डिलीवरी (COD) ऑर्डर फॉर्म
          </h2>
          <p className="mt-1 text-xs sm:text-sm text-stone-600">
            नीचे अपना पता भरें और सामान घर पहुंचने पर पैसे दें
          </p>
        </div>

        {/* ORDER SUCCESS MODAL / VIEW */}
        {orderSuccessData ? (
          <div className="bg-white rounded-3xl p-6 sm:p-10 border-2 border-emerald-500 shadow-2xl text-center space-y-6 animate-fade-in">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                ऑर्डर सफलतापूर्वक दर्ज हो गया!
              </span>
              <h3 className="text-2xl font-extrabold text-stone-900">
                धन्यवाद, {orderSuccessData.name}!
              </h3>
              <p className="text-xs sm:text-sm text-stone-600 max-w-md mx-auto">
                आपका ऑर्डर स्वीकार कर लिया गया है। हमारी टीम जल्द ही आपके नंबर पर पुष्टि (Verification Call) करेगी।
              </p>
            </div>

            {/* Receipt Summary */}
            <div className="bg-stone-50 rounded-2xl p-4 sm:p-5 border border-stone-200 text-left max-w-md mx-auto space-y-2.5 text-xs sm:text-sm">
              <div className="flex justify-between border-b border-stone-200 pb-2">
                <span className="text-stone-500 font-medium">ऑर्डर संदर्भ संख्या (Order ID):</span>
                <span className="font-mono font-bold text-stone-900">{orderSuccessData.orderId}</span>
              </div>
              <div className="flex justify-between border-b border-stone-200 pb-2">
                <span className="text-stone-500 font-medium">चुना गया पैक:</span>
                <span className="font-bold text-stone-900">{orderSuccessData.offer}</span>
              </div>
              <div className="flex justify-between border-b border-stone-200 pb-2">
                <span className="text-stone-500 font-medium">भुगतान विधि:</span>
                <span className="font-semibold text-emerald-800">{orderSuccessData.payment}</span>
              </div>
              <div className="flex justify-between border-b border-stone-200 pb-2">
                <span className="text-stone-500 font-medium">डिलीवरी चार्ज:</span>
                <span className="font-bold text-emerald-600">मुफ़्त (FREE)</span>
              </div>
              <div className="flex justify-between pt-1 text-base">
                <span className="font-extrabold text-stone-900">कुल देय राशि:</span>
                <span className="font-extrabold text-amber-900 font-mono text-lg">₹{orderSuccessData.total}/-</span>
              </div>
            </div>

            {/* Follow-up actions */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <a
                href={`tel:${PRODUCT_INFO.supportPhone}`}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold text-sm rounded-xl shadow-md transition-all"
              >
                <Phone className="w-4 h-4" />
                <span>हेल्पलाइन पर कॉल करें: {PRODUCT_INFO.supportPhone}</span>
              </a>

              <button
                onClick={handleReset}
                className="w-full sm:w-auto px-6 py-3 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-sm rounded-xl transition-all cursor-pointer"
              >
                दूसरा ऑर्डर करें
              </button>
            </div>

            <div className="text-[11px] text-stone-500 flex items-center justify-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>गोपनीय पार्सल 3 से 5 दिनों में आपके पते पर पहुंचा दिया जाएगा।</span>
            </div>
          </div>
        ) : (
          /* MAIN BOOKING FORM */
          <div className="bg-white rounded-3xl p-6 sm:p-8 md:p-10 border border-amber-200 shadow-xl shadow-amber-950/5 relative">
            
            {/* Top Guarantees Strip */}
            <div className="grid grid-cols-3 gap-2 pb-6 mb-6 border-b border-stone-100 text-center">
              <div className="flex flex-col items-center">
                <span className="text-emerald-600 font-bold text-xs sm:text-sm">💵 COD उपलब्ध</span>
                <span className="text-[10px] sm:text-xs text-stone-500">घर पर नकद भुगतान</span>
              </div>
              <div className="flex flex-col items-center border-x border-stone-200">
                <span className="text-amber-700 font-bold text-xs sm:text-sm">🚚 0₹ शिपिंग</span>
                <span className="text-[10px] sm:text-xs text-stone-500">मुफ़्त होम डिलीवरी</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-indigo-600 font-bold text-xs sm:text-sm">🔒 गुप्त पैकिंग</span>
                <span className="text-[10px] sm:text-xs text-stone-500">100% सुरक्षित पार्सल</span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Step 1: Package Selection */}
              <div>
                <OfferSelector
                  selectedOffer={selectedOffer}
                  onSelectOffer={setSelectedOffer}
                />
              </div>

              {/* Step 2: Shipping Details */}
              <div className="pt-2 border-t border-stone-100 space-y-4">
                <h3 className="text-sm font-bold text-stone-900 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-amber-600" />
                  <span>डिलीवरी का पता भरें (Delivery Address)</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Full Name */}
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      पूरा नाम (Full Name) <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                      <input
                        type="text"
                        required
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="उदा. राजेश कुमार"
                        className="w-full pl-9 pr-3 py-2.5 text-sm rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                      />
                    </div>
                  </div>

                  {/* Mobile Number */}
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      मोबाइल नंबर (संपर्क / कॉलिंग नंबर) <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                      <input
                        type="tel"
                        required
                        maxLength={10}
                        value={phone}
                        onChange={(e) => setPhone(e.target.value.replace(/[^0-9]/g, ''))}
                        placeholder="10 अंकों का मोबाइल नंबर"
                        className="w-full pl-9 pr-3 py-2.5 text-sm rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-mono"
                      />
                    </div>
                  </div>
                </div>

                {/* Complete Address */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    पूरा पता (मकान नं., गली, मोहल्ला / गांव, लैंडमार्क) <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    required
                    rows={2}
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="उदा. मकान नं. 14, शिव मंदिर के पास, मेन रोड..."
                    className="w-full px-3 py-2.5 text-sm rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  ></textarea>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* City */}
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      शहर / कस्बा (City) <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="उदा. जयपुर / लखनऊ"
                      className="w-full px-3 py-2.5 text-sm rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                    />
                  </div>

                  {/* State */}
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      राज्य (State) <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={stateName}
                      onChange={(e) => setStateName(e.target.value)}
                      className="w-full px-3 py-2.5 text-sm rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 bg-white"
                    >
                      {indianStates.map((st) => (
                        <option key={st} value={st}>{st}</option>
                      ))}
                    </select>
                  </div>

                  {/* Pincode */}
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      पिनकोड (Pincode) <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={6}
                      value={pincode}
                      onChange={(e) => setPincode(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="6 अंकों का पिनकोड"
                      className="w-full px-3 py-2.5 text-sm rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-mono"
                    />
                  </div>
                </div>

              </div>

              {/* Step 3: Payment Method */}
              <div className="pt-2 border-t border-stone-100">
                <label className="block text-xs font-bold text-stone-900 mb-2">
                  भुगतान का माध्यम (Payment Method)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div
                    onClick={() => setPaymentMethod('COD')}
                    className={`p-3.5 rounded-xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                      paymentMethod === 'COD'
                        ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 font-bold'
                        : 'border-stone-200 bg-white text-stone-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                        paymentMethod === 'COD' ? 'border-emerald-600 bg-emerald-600 text-white' : 'border-stone-400'
                      }`}>
                        {paymentMethod === 'COD' && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                      </div>
                      <div>
                        <div className="text-sm">कैश ऑन डिलीवरी (COD)</div>
                        <div className="text-[11px] text-stone-500">घर पर पार्सल मिलने पर भुगतान</div>
                      </div>
                    </div>
                    <span className="text-xs bg-emerald-200/60 text-emerald-800 px-2 py-0.5 rounded font-bold">
                      लोकप्रिय
                    </span>
                  </div>

                  <div
                    onClick={() => setPaymentMethod('UPI')}
                    className={`p-3.5 rounded-xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                      paymentMethod === 'UPI'
                        ? 'border-amber-600 bg-amber-50/70 text-amber-950 font-bold'
                        : 'border-stone-200 bg-white text-stone-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                        paymentMethod === 'UPI' ? 'border-amber-600 bg-amber-600 text-white' : 'border-stone-400'
                      }`}>
                        {paymentMethod === 'UPI' && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                      </div>
                      <div>
                        <div className="text-sm">UPI / QR कोड / ऑनलाइन</div>
                        <div className="text-[11px] text-stone-500">GPay, PhonePe, Paytm</div>
                      </div>
                    </div>
                    <span className="text-xs text-stone-500">
                      फास्ट
                    </span>
                  </div>
                </div>
              </div>

              {/* Order Final Summary */}
              <div className="bg-amber-50/80 p-4 rounded-2xl border border-amber-200 space-y-2">
                <div className="flex justify-between text-xs sm:text-sm text-stone-700">
                  <span>चयनित उत्पाद:</span>
                  <span className="font-bold">{PRODUCT_INFO.name} - {selectedOffer.weight}</span>
                </div>
                <div className="flex justify-between text-xs sm:text-sm text-stone-700">
                  <span>डिलीवरी शुल्क:</span>
                  <span className="text-emerald-700 font-bold">मुफ़्त (FREE)</span>
                </div>
                <div className="flex justify-between text-xs sm:text-sm text-stone-700">
                  <span>आपकी कुल बचत:</span>
                  <span className="text-emerald-700 font-bold">₹{selectedOffer.savings}/-</span>
                </div>
                <div className="flex justify-between text-base sm:text-lg font-black text-stone-900 pt-2 border-t border-amber-200">
                  <span>कुल देय राशि (Total Amount):</span>
                  <span className="text-amber-900 font-mono text-xl">₹{selectedOffer.price}/-</span>
                </div>
              </div>

              {/* Submit CTA Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                id="submit-order-btn"
                className="w-full py-4 px-6 bg-gradient-to-r from-amber-600 via-amber-700 to-amber-800 hover:from-amber-700 hover:to-amber-900 text-white font-extrabold text-base sm:text-lg rounded-2xl shadow-xl shadow-amber-700/25 active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70"
              >
                {isSubmitting ? (
                  <span>ऑर्डर प्रोसेस हो रहा है... कृपया प्रतीक्षा करें</span>
                ) : (
                  <>
                    <ShoppingBag className="w-5 h-5" />
                    <span>ऑर्डर कन्फर्म करें (₹{selectedOffer.price}/- COD)</span>
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>

              <div className="text-center space-y-1">
                <p className="text-[11px] sm:text-xs text-stone-500 flex items-center justify-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-stone-400" />
                  <span>आपकी जानकारी 100% सुरक्षित और गोपनीय रखी जाती है।</span>
                </p>
                <p className="text-[11px] text-amber-800 font-medium">
                  {PRODUCT_INFO.deliveryTimeline}
                </p>
              </div>

            </form>
          </div>
        )}

      </div>
    </section>
  );
};
