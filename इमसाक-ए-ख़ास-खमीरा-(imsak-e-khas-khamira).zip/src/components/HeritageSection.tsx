import React from 'react';
import { Scroll, Award, Leaf, Flame, ShieldAlert } from 'lucide-react';
import { PRODUCT_INFO } from '../data/productData';

export const HeritageSection: React.FC = () => {
  return (
    <section className="py-12 md:py-16 bg-gradient-to-b from-stone-50 to-amber-50/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-amber-200/80 shadow-md shadow-amber-900/5 relative overflow-hidden">
          
          {/* Subtle decorative watermark */}
          <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-amber-100/40 rounded-full blur-2xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-8 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold">
                <Leaf className="w-3.5 h-3.5 text-emerald-600" />
                <span>🌿 पारंपरिक हर्बल फॉर्मूला</span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight">
                पारंपरिक ज्ञान और प्राकृतिक शुद्धता का संगम
              </h2>

              <p className="text-stone-700 text-base sm:text-lg leading-relaxed font-medium">
                {PRODUCT_INFO.heritageText}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-amber-50/70 border border-amber-100">
                  <div className="w-9 h-9 rounded-lg bg-amber-600 text-white flex items-center justify-center shrink-0">
                    <Scroll className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-900 text-sm">प्राचीन खमीरा विधा</h4>
                    <p className="text-xs text-stone-600 mt-0.5">
                      शहद व प्राकृतिक जड़ी-बूटियों को विशेष प्रक्रिया द्वारा धीमी आंच पर पकाकर तैयार किया गया फॉर्मूला।
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-amber-50/70 border border-amber-100">
                  <div className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-900 text-sm">हर्बल और सुरक्षित</h4>
                    <p className="text-xs text-stone-600 mt-0.5">
                      पारंपरिक चिकित्सा पद्धतियों में सदियों से परीक्षित, कोई हानिकारक कृत्रिम रसायन नहीं।
                    </p>
                  </div>
                </div>
              </div>

            </div>

            <div className="lg:col-span-4 flex flex-col items-center justify-center">
              <div className="w-full max-w-xs bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 text-white p-6 rounded-2xl shadow-lg border border-amber-400/40 text-center">
                <span className="text-4xl mb-2 inline-block">🍯</span>
                <h3 className="font-extrabold text-xl mb-1">खमीरा क्या है?</h3>
                <p className="text-xs text-amber-100 leading-relaxed mb-4">
                  खमीरा पारंपरिक चिकित्सा की वह विशिष्ट औषधि श्रेणी है जो शरीर की दुर्बलता को दूर कर ऊर्जा का संचार करने के लिए जानी जाती है।
                </p>
                <div className="inline-block bg-amber-900/50 px-3 py-1.5 rounded-lg text-xs font-bold text-amber-200 border border-amber-400/30">
                  शुद्ध प्राकृतिक तत्वों से निर्मित
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
