import React, { useState } from 'react';
import { 
  Sparkles, 
  ShieldCheck, 
  Leaf, 
  HeartPulse, 
  Droplets, 
  Zap, 
  Flame, 
  CheckCircle2, 
  Sprout, 
  Wind, 
  Award,
  Info
} from 'lucide-react';
import { HERBAL_INGREDIENTS } from '../data/productData';

// Map ingredient IDs to representative Lucide icons and distinct gentle color accents
const INGREDIENT_ICONS: Record<string, { 
  icon: React.ReactNode; 
  bgColor: string; 
  borderColor: string; 
  iconColor: string; 
}> = {
  saffron: {
    icon: <Flame className="w-5 h-5" />,
    bgColor: "bg-amber-100/80",
    borderColor: "border-amber-300",
    iconColor: "text-amber-700"
  },
  musli: {
    icon: <Zap className="w-5 h-5" />,
    bgColor: "bg-emerald-100/80",
    borderColor: "border-emerald-300",
    iconColor: "text-emerald-700"
  },
  ashwagandha: {
    icon: <HeartPulse className="w-5 h-5" />,
    bgColor: "bg-rose-100/80",
    borderColor: "border-rose-300",
    iconColor: "text-rose-700"
  },
  honey: {
    icon: <Droplets className="w-5 h-5" />,
    bgColor: "bg-amber-100",
    borderColor: "border-amber-400",
    iconColor: "text-amber-800"
  },
  kaunch: {
    icon: <ShieldCheck className="w-5 h-5" />,
    bgColor: "bg-indigo-100/80",
    borderColor: "border-indigo-300",
    iconColor: "text-indigo-700"
  },
  gokhru: {
    icon: <Sparkles className="w-5 h-5" />,
    bgColor: "bg-orange-100/80",
    borderColor: "border-orange-300",
    iconColor: "text-orange-700"
  },
  shatavari: {
    icon: <Sprout className="w-5 h-5" />,
    bgColor: "bg-teal-100/80",
    borderColor: "border-teal-300",
    iconColor: "text-teal-700"
  },
  spices: {
    icon: <Wind className="w-5 h-5" />,
    bgColor: "bg-stone-100",
    borderColor: "border-stone-300",
    iconColor: "text-stone-700"
  }
};

export const IngredientsSection: React.FC = () => {
  const [selectedIngredientId, setSelectedIngredientId] = useState<string | null>(null);

  return (
    <section id="ingredients" className="py-14 md:py-20 bg-gradient-to-b from-stone-50 via-amber-50/30 to-white relative overflow-hidden border-t border-amber-100/60">
      {/* Background ambient accents */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-200/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-emerald-200/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 md:mb-14">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-amber-100 text-amber-900 text-xs font-bold mb-3 border border-amber-300/80 shadow-xs">
            <Leaf className="w-3.5 h-3.5 text-amber-700" />
            <span>100% प्राकृतिक एवं प्रामाणिक जड़ी-बूटियाँ</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-stone-900 tracking-tight leading-tight">
            इमसाक-ए-ख़ास खमीरा के मुख्य प्राकृतिक हर्बल घटक
          </h2>

          <p className="mt-3 text-sm sm:text-base text-stone-600 leading-relaxed font-normal">
            पारंपरिक यूनानी एवं आयुर्वेदिक पद्धति के अनुसार चयनित शुद्ध जड़ी-बूटियों और शुद्ध शहद का ऐसा संतुलित मिश्रण, जो बिना किसी कृत्रिम रसायन के शरीर को प्राकृतिक शक्ति प्रदान करता है।
          </p>

          {/* Quick Quality Guarantee Strip */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3 text-xs text-stone-700">
            <span className="inline-flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-stone-200 shadow-xs font-medium">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> कोई हानिकारक रसायन नहीं
            </span>
            <span className="inline-flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-stone-200 shadow-xs font-medium">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> 100% शाकाहारी व सुरक्षित
            </span>
            <span className="inline-flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-stone-200 shadow-xs font-medium">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> शुद्ध शहद का पारंपरिक बेस
            </span>
            <span className="inline-flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-stone-200 shadow-xs font-medium">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> पारंपरिक धीमी आंच निर्माण
            </span>
          </div>
        </div>

        {/* Ingredients Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
          {HERBAL_INGREDIENTS.map((ingredient) => {
            const iconConfig = INGREDIENT_ICONS[ingredient.id] || {
              icon: <Leaf className="w-5 h-5" />,
              bgColor: "bg-amber-100",
              borderColor: "border-amber-300",
              iconColor: "text-amber-700"
            };

            const isSelected = selectedIngredientId === ingredient.id;

            return (
              <div
                key={ingredient.id}
                onClick={() => setSelectedIngredientId(isSelected ? null : ingredient.id)}
                className={`bg-white rounded-2xl p-5 border transition-all duration-300 flex flex-col justify-between cursor-pointer group hover:-translate-y-1 ${
                  isSelected
                    ? 'border-amber-500 shadow-lg ring-2 ring-amber-400/50 bg-amber-50/30'
                    : 'border-amber-100/90 shadow-md shadow-amber-950/5 hover:border-amber-300 hover:shadow-xl'
                }`}
              >
                <div>
                  {/* Top Row: Icon + Badge */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className={`w-11 h-11 rounded-xl ${iconConfig.bgColor} ${iconConfig.borderColor} ${iconConfig.iconColor} border flex items-center justify-center shadow-xs transition-transform group-hover:scale-110`}>
                      {iconConfig.icon}
                    </div>

                    {ingredient.badge && (
                      <span className="text-[10px] font-bold text-amber-900 bg-amber-100/90 px-2 py-0.5 rounded-full border border-amber-200">
                        {ingredient.badge}
                      </span>
                    )}
                  </div>

                  {/* Ingredient Name */}
                  <h3 className="font-extrabold text-stone-900 text-base group-hover:text-amber-900 transition-colors">
                    {ingredient.name}
                  </h3>

                  <p className="text-[11px] font-mono text-stone-600 mb-2">
                    {ingredient.englishName}
                  </p>

                  {/* Core Action Highlight */}
                  <div className="inline-block bg-amber-50 text-amber-950 text-xs font-semibold px-2.5 py-1 rounded-lg border border-amber-200/80 mb-2.5">
                    ✨ {ingredient.role}
                  </div>

                  {/* Description */}
                  <p className="text-xs text-stone-600 leading-relaxed">
                    {ingredient.desc}
                  </p>
                </div>

                {/* Footer Tag */}
                <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-[11px]">
                  <span className="text-stone-600 font-medium">श्रेणी:</span>
                  <span className="font-bold text-amber-800 bg-stone-100 px-2 py-0.5 rounded-md">
                    {ingredient.category}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Trust & Classical Assurance Card */}
        <div className="mt-10 bg-gradient-to-r from-amber-950 via-stone-900 to-amber-950 rounded-2xl p-5 sm:p-7 text-white shadow-xl border border-amber-700/40">
          <div className="flex flex-col md:flex-row items-center gap-5 justify-between">
            <div className="flex items-start gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center shrink-0 text-amber-300">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-base sm:text-lg font-black text-amber-300">
                  शुद्धता और प्रामाणिकता की गारंटी (Purity Assurance)
                </h4>
                <p className="text-xs sm:text-sm text-stone-300 mt-1 max-w-3xl leading-relaxed">
                  इमसाक-ए-ख़ास खमीरा में किसी भी प्रकार का हानिकारक रसायन, स्टेरॉयड या सिंथेटिक रंग नहीं मिलाया जाता। यह पारंपरिक यूनानी काढ़े, असली जाफ़रान और शुद्ध वन शहद के साथ धीमी आंच पर पकाया जाने वाला प्रामाणिक वेलनेस खमीरा है।
                </p>
              </div>
            </div>

            <div className="shrink-0 w-full md:w-auto text-center md:text-right">
              <span className="inline-flex items-center gap-1.5 bg-emerald-500/20 text-emerald-300 text-xs font-bold px-3.5 py-2 rounded-xl border border-emerald-400/30">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                लैब-टेस्टेड व सुरक्षित फॉर्मूला
              </span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
