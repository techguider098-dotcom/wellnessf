import React from 'react';
import { Target, ShieldCheck, Check, ArrowRight } from 'lucide-react';
import { WHO_IS_IT_FOR, WHY_CHOOSE_US } from '../data/productData';

interface WhoIsItForProps {
  onOrderClick: () => void;
}

export const WhoIsItFor: React.FC<WhoIsItForProps> = ({ onOrderClick }) => {
  return (
    <section className="py-12 md:py-16 bg-stone-50 border-b border-amber-100/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          
          {/* Card 1: 🎯 यह किसके लिए उपयोगी हो सकता है? */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-amber-200/80 shadow-md flex flex-col justify-between">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-900 border border-blue-200 text-xs font-bold mb-3">
                <Target className="w-3.5 h-3.5 text-blue-600" />
                <span>लक्षित उपयोग (Target Audience)</span>
              </div>

              <h3 className="text-xl sm:text-2xl font-extrabold text-stone-900 mb-2">
                🎯 यह किसके लिए उपयोगी हो सकता है?
              </h3>
              <p className="text-xs sm:text-sm text-stone-600 mb-6">
                यदि आप अपनी दैनिक ऊर्जा, स्टैमिना और कार्यक्षमता में गिरावट महसूस कर रहे हैं, तो यह फॉर्मूला विशेष रूप से आपके लिए है:
              </p>

              <div className="space-y-3.5">
                {WHO_IS_IT_FOR.map((item, idx) => (
                  <div 
                    key={idx} 
                    className="flex items-start gap-3 p-3.5 rounded-xl bg-amber-50/50 border border-amber-100/70"
                  >
                    <span className="flex items-center justify-center w-6 h-6 rounded-full bg-emerald-600 text-white shrink-0 text-xs font-bold mt-0.5">
                      ✔
                    </span>
                    <span className="text-stone-800 text-sm font-semibold leading-relaxed">
                      {item}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-stone-100">
              <button
                onClick={onOrderClick}
                className="w-full py-3 px-4 bg-amber-600 hover:bg-amber-700 text-white font-bold text-sm rounded-xl transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <span>हां, मुझे इसकी आवश्यकता है - ऑर्डर करें</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Card 2: 🛡️ क्यों चुनें इमसाक-ए-ख़ास खमीरा? */}
          <div className="bg-gradient-to-br from-amber-950 via-stone-900 to-amber-950 text-white rounded-3xl p-6 sm:p-8 border border-amber-700/50 shadow-xl flex flex-col justify-between">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-900/60 text-amber-200 border border-amber-500/30 text-xs font-bold mb-3">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>हमारी विशेषताएँ</span>
              </div>

              <h3 className="text-xl sm:text-2xl font-extrabold text-amber-200 mb-2">
                🛡️ क्यों चुनें इमसाक-ए-ख़ास खमीरा?
              </h3>
              <p className="text-xs sm:text-sm text-stone-300 mb-6">
                बाज़ार में उपलब्ध कृत्रिम सप्लीमेंट्स की तुलना में हमारा पारंपरिक फॉर्मूला प्राकृतिक और सुरक्षित विकल्प है:
              </p>

              <div className="space-y-3.5">
                {WHY_CHOOSE_US.map((item, idx) => (
                  <div 
                    key={idx} 
                    className="flex items-start gap-3 p-3.5 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
                  >
                    <span className="flex items-center justify-center w-6 h-6 rounded-full bg-amber-500 text-stone-950 shrink-0 text-xs font-bold mt-0.5">
                      ✔
                    </span>
                    <div>
                      <h4 className="text-amber-300 text-sm font-bold">
                        {item.title}
                      </h4>
                      <p className="text-stone-300 text-xs mt-0.5 leading-relaxed">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-xs text-amber-300/90 font-medium">
              <span>✓ 100% संतोषजनक अनुभव</span>
              <span>✓ कैश ऑन डिलीवरी उपलब्ध</span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
