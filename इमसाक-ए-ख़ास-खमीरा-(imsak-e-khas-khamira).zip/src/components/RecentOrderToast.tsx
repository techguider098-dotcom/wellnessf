import React, { useState, useEffect } from 'react';
import { ShoppingBag, X, CheckCircle2 } from 'lucide-react';
import { RECENT_ORDERS_SIMULATED } from '../data/productData';

export const RecentOrderToast: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (dismissed) return;

    // Show after 3 seconds initially
    const initialTimeout = setTimeout(() => {
      setVisible(true);
    }, 3500);

    // Rotate every 12 seconds
    const interval = setInterval(() => {
      setVisible(false);
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % RECENT_ORDERS_SIMULATED.length);
        setVisible(true);
      }, 800);
    }, 14000);

    return () => {
      clearTimeout(initialTimeout);
      clearInterval(interval);
    };
  }, [dismissed]);

  if (dismissed || !visible) return null;

  const currentOrder = RECENT_ORDERS_SIMULATED[currentIndex];

  return (
    <div className="fixed bottom-20 md:bottom-6 left-4 z-30 max-w-xs sm:max-w-sm bg-white/95 backdrop-blur-md rounded-2xl p-3 border border-amber-200/90 shadow-xl shadow-stone-900/10 flex items-center gap-3 transition-all duration-500 animate-slide-up">
      <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-800 flex items-center justify-center shrink-0 border border-amber-300">
        <ShoppingBag className="w-5 h-5 text-amber-700" />
      </div>

      <div className="flex-1 min-w-0 pr-1">
        <div className="flex items-center gap-1.5">
          <span className="font-extrabold text-stone-900 text-xs truncate">
            {currentOrder.name} ({currentOrder.city})
          </span>
          <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
        </div>
        <p className="text-[11px] text-stone-600 truncate">
          ने <strong>{currentOrder.pack}</strong> ऑर्डर किया
        </p>
        <span className="text-[9px] text-stone-400 font-medium">{currentOrder.time}</span>
      </div>

      <button
        onClick={() => setDismissed(true)}
        className="p-1 text-stone-400 hover:text-stone-700 rounded-md"
        title="बंद करें"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
